package View;

import Main.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class MasterDashboard extends javax.swing.JPanel {
    
    private Connection conn;
    
    public MasterDashboard() {
        initComponents();
        conn = Koneksi.getConnection();
        loadData();
        setTableModelPeminjaman();
        getDataPeminjaman((DefaultTableModel) tblData.getModel());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cardAnggota = new Palette.Custom_JPanelRounded();
        lb_anggota = new javax.swing.JLabel();
        lbJumlahAnggota = new javax.swing.JLabel();
        lb_iconAnggota = new javax.swing.JLabel();
        cardAnggota1 = new Palette.Custom_JPanelRounded();
        lb_anggota1 = new javax.swing.JLabel();
        lbJumlahBuku = new javax.swing.JLabel();
        lb_iconAnggota1 = new javax.swing.JLabel();
        cardAnggota2 = new Palette.Custom_JPanelRounded();
        lb_anggota2 = new javax.swing.JLabel();
        lbJumlahPeminjaman = new javax.swing.JLabel();
        lb_iconAnggota2 = new javax.swing.JLabel();
        cardAnggota3 = new Palette.Custom_JPanelRounded();
        lb_anggota3 = new javax.swing.JLabel();
        lbJumlahPengembalian = new javax.swing.JLabel();
        lb_iconAnggota3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblData = new Palette.Custom_JTabel();
        jLabel1 = new javax.swing.JLabel();

        setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1133, 690));

        cardAnggota.setBackground(new java.awt.Color(102, 153, 255));
        cardAnggota.setRoundBottomLeft(30);
        cardAnggota.setRoundBottomRight(30);
        cardAnggota.setRoundTopLeft(30);
        cardAnggota.setRoundTopRight(30);

        lb_anggota.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lb_anggota.setForeground(new java.awt.Color(153, 153, 153));
        lb_anggota.setText("ANGGOTA");

        lbJumlahAnggota.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lbJumlahAnggota.setForeground(new java.awt.Color(0, 102, 153));
        lbJumlahAnggota.setText("999");

        lb_iconAnggota.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lb_iconAnggota.setForeground(new java.awt.Color(0, 102, 153));
        lb_iconAnggota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icons8_people_70px.png"))); // NOI18N

        javax.swing.GroupLayout cardAnggotaLayout = new javax.swing.GroupLayout(cardAnggota);
        cardAnggota.setLayout(cardAnggotaLayout);
        cardAnggotaLayout.setHorizontalGroup(
            cardAnggotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggotaLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(cardAnggotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbJumlahAnggota)
                    .addComponent(lb_anggota))
                .addGap(50, 50, 50)
                .addComponent(lb_iconAnggota)
                .addGap(20, 20, 20))
        );
        cardAnggotaLayout.setVerticalGroup(
            cardAnggotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggotaLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(cardAnggotaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_iconAnggota)
                    .addGroup(cardAnggotaLayout.createSequentialGroup()
                        .addComponent(lb_anggota)
                        .addGap(20, 20, 20)
                        .addComponent(lbJumlahAnggota)))
                .addGap(20, 20, 20))
        );

        cardAnggota1.setBackground(new java.awt.Color(102, 153, 255));
        cardAnggota1.setRoundBottomLeft(30);
        cardAnggota1.setRoundBottomRight(30);
        cardAnggota1.setRoundTopLeft(30);
        cardAnggota1.setRoundTopRight(30);

        lb_anggota1.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lb_anggota1.setForeground(new java.awt.Color(153, 153, 153));
        lb_anggota1.setText("BUKU");

        lbJumlahBuku.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lbJumlahBuku.setForeground(new java.awt.Color(0, 102, 153));
        lbJumlahBuku.setText("999");

        lb_iconAnggota1.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lb_iconAnggota1.setForeground(new java.awt.Color(0, 102, 153));
        lb_iconAnggota1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icons8_book_70px.png"))); // NOI18N

        javax.swing.GroupLayout cardAnggota1Layout = new javax.swing.GroupLayout(cardAnggota1);
        cardAnggota1.setLayout(cardAnggota1Layout);
        cardAnggota1Layout.setHorizontalGroup(
            cardAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(cardAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbJumlahBuku)
                    .addComponent(lb_anggota1))
                .addGap(50, 50, 50)
                .addComponent(lb_iconAnggota1)
                .addGap(20, 20, 20))
        );
        cardAnggota1Layout.setVerticalGroup(
            cardAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(cardAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_iconAnggota1)
                    .addGroup(cardAnggota1Layout.createSequentialGroup()
                        .addComponent(lb_anggota1)
                        .addGap(20, 20, 20)
                        .addComponent(lbJumlahBuku)))
                .addGap(20, 20, 20))
        );

        cardAnggota2.setBackground(new java.awt.Color(102, 153, 255));
        cardAnggota2.setRoundBottomLeft(30);
        cardAnggota2.setRoundBottomRight(30);
        cardAnggota2.setRoundTopLeft(30);
        cardAnggota2.setRoundTopRight(30);

        lb_anggota2.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lb_anggota2.setForeground(new java.awt.Color(153, 153, 153));
        lb_anggota2.setText("PEMINJAMAN");

        lbJumlahPeminjaman.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lbJumlahPeminjaman.setForeground(new java.awt.Color(0, 102, 153));
        lbJumlahPeminjaman.setText("999");

        lb_iconAnggota2.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lb_iconAnggota2.setForeground(new java.awt.Color(0, 102, 153));
        lb_iconAnggota2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icons8_borrow_book_70px.png"))); // NOI18N

        javax.swing.GroupLayout cardAnggota2Layout = new javax.swing.GroupLayout(cardAnggota2);
        cardAnggota2.setLayout(cardAnggota2Layout);
        cardAnggota2Layout.setHorizontalGroup(
            cardAnggota2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(cardAnggota2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbJumlahPeminjaman)
                    .addComponent(lb_anggota2))
                .addGap(50, 50, 50)
                .addComponent(lb_iconAnggota2)
                .addGap(20, 20, 20))
        );
        cardAnggota2Layout.setVerticalGroup(
            cardAnggota2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(cardAnggota2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_iconAnggota2)
                    .addGroup(cardAnggota2Layout.createSequentialGroup()
                        .addComponent(lb_anggota2)
                        .addGap(20, 20, 20)
                        .addComponent(lbJumlahPeminjaman)))
                .addGap(20, 20, 20))
        );

        cardAnggota3.setBackground(new java.awt.Color(102, 153, 255));
        cardAnggota3.setRoundBottomLeft(30);
        cardAnggota3.setRoundBottomRight(30);
        cardAnggota3.setRoundTopLeft(30);
        cardAnggota3.setRoundTopRight(30);

        lb_anggota3.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        lb_anggota3.setForeground(new java.awt.Color(153, 153, 153));
        lb_anggota3.setText("PENGEMBALIAN");

        lbJumlahPengembalian.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lbJumlahPengembalian.setForeground(new java.awt.Color(0, 102, 153));
        lbJumlahPengembalian.setText("999");

        lb_iconAnggota3.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        lb_iconAnggota3.setForeground(new java.awt.Color(0, 102, 153));
        lb_iconAnggota3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/icons8_return_book_70px.png"))); // NOI18N

        javax.swing.GroupLayout cardAnggota3Layout = new javax.swing.GroupLayout(cardAnggota3);
        cardAnggota3.setLayout(cardAnggota3Layout);
        cardAnggota3Layout.setHorizontalGroup(
            cardAnggota3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(cardAnggota3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbJumlahPengembalian)
                    .addComponent(lb_anggota3))
                .addGap(50, 50, 50)
                .addComponent(lb_iconAnggota3)
                .addGap(20, 20, 20))
        );
        cardAnggota3Layout.setVerticalGroup(
            cardAnggota3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardAnggota3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(cardAnggota3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_iconAnggota3)
                    .addGroup(cardAnggota3Layout.createSequentialGroup()
                        .addComponent(lb_anggota3)
                        .addGap(20, 20, 20)
                        .addComponent(lbJumlahPengembalian)))
                .addGap(20, 20, 20))
        );

        tblData.setForeground(new java.awt.Color(255, 51, 51));
        jScrollPane1.setViewportView(tblData);

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Riwayat Peminjaman Buku");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cardAnggota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(cardAnggota1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(cardAnggota2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(cardAnggota3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addGap(0, 26, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cardAnggota3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cardAnggota2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cardAnggota1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cardAnggota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        add(jPanel1, "card2");
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Palette.Custom_JPanelRounded cardAnggota;
    private Palette.Custom_JPanelRounded cardAnggota1;
    private Palette.Custom_JPanelRounded cardAnggota2;
    private Palette.Custom_JPanelRounded cardAnggota3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbJumlahAnggota;
    private javax.swing.JLabel lbJumlahBuku;
    private javax.swing.JLabel lbJumlahPeminjaman;
    private javax.swing.JLabel lbJumlahPengembalian;
    private javax.swing.JLabel lb_anggota;
    private javax.swing.JLabel lb_anggota1;
    private javax.swing.JLabel lb_anggota2;
    private javax.swing.JLabel lb_anggota3;
    private javax.swing.JLabel lb_iconAnggota;
    private javax.swing.JLabel lb_iconAnggota1;
    private javax.swing.JLabel lb_iconAnggota2;
    private javax.swing.JLabel lb_iconAnggota3;
    private Palette.Custom_JTabel tblData;
    // End of variables declaration//GEN-END:variables

    private int jumlahAnggota(){
        int totalAnggota = 0;
        
        try {
            String sql = "SELECT COUNT(*) AS total FROM anggota";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                totalAnggota = rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalAnggota;
    }
    
    private int jumlahBuku(){
        int totalBuku = 0;
        
        try {
            String sql = "SELECT COUNT(*) AS total FROM buku";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                totalBuku = rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalBuku;
    }
    
    private int jumlahPeminjaman(){
        int totalPeminjaman = 0;
        
        try {
            String sql = "SELECT COUNT(*) AS total FROM detail_peminjaman";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                totalPeminjaman = rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalPeminjaman;
    }
    
    private int jumlahPengembalian(){
        int totalPengembalian = 0;
        
        try {
            String sql = "SELECT COUNT(*) AS total FROM detail_peminjaman WHERE Status_Peminjaman ='Sudah dikembalikan'";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                totalPengembalian = rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalPengembalian;
    }
    
    private void setTableModelPeminjaman(){
        DefaultTableModel model = (DefaultTableModel) tblData.getModel();
        model.addColumn("ID Peminjaman");
        model.addColumn("Tanggal Pinjam");
        model.addColumn("Tanggal Kembali");
        model.addColumn("Nama Anggota");
        model.addColumn("ID Buku");
        model.addColumn("Judul");
        model.addColumn("Jumlah Pinjam");
        model.addColumn("Status Peminjaman");
    }
    
    private void getDataPeminjaman(DefaultTableModel model){
        model.setRowCount(0);
        
        try {
            String sql = "SELECT pmd.ID_Peminjaman,pmj.Tanggal_Peminjaman, "
                    + "pmj.Tanggal_Pengembalian, agt.Nama_Anggota, bk.ID_Buku, "
                    + "bk.Judul_Buku, pmd.Jumlah_Pinjam, pmd.Status_Peminjaman\n" +
                        "FROM detail_peminjaman pmd\n" +
                        "INNER JOIN peminjaman pmj ON pmj.ID_Peminjaman = pmd.ID_Peminjaman\n" +
                        "INNER JOIN buku bk ON bk.ID_Buku = pmd.ID_Buku\n" +
                        "INNER JOIN anggota agt ON agt.ID_Anggota = pmj.ID_Anggota "
                    + "ORDER BY pmd.ID_Peminjaman DESC";
            
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            while(rs.next()){
                String idPeminjaman         = rs.getString("ID_Peminjaman");
                String tanggalPeminjaman    = rs.getString("Tanggal_Peminjaman");
                String tanggalPengembalian  = rs.getString("Tanggal_Pengembalian");
                String namaAnggota          = rs.getString("Nama_Anggota");
                String idBuku               = rs.getString("ID_Buku");
                String judulBuku            = rs.getString("Judul_Buku");
                String jumlahPinjam         = rs.getString("Jumlah_Pinjam");
                String statusPeminjaman     = rs.getString("Status_Peminjaman");
                
                Object[] rowData = {idPeminjaman, tanggalPeminjaman, tanggalPengembalian, namaAnggota, idBuku, judulBuku, jumlahPinjam, statusPeminjaman};
                model.addRow(rowData);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadData() {
        lbJumlahAnggota.setText(String.valueOf(jumlahAnggota()));
        lbJumlahBuku.setText(String.valueOf(jumlahBuku()));
        lbJumlahPeminjaman.setText(String.valueOf(jumlahPeminjaman()));
        lbJumlahPengembalian.setText(String.valueOf(jumlahPengembalian()));
    }
}
